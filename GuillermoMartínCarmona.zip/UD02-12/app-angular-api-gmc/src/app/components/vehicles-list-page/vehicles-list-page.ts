import { Component, inject, OnInit, signal } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Result } from '../../interfaces/vehicle-list-response';
import { VehicleService } from '../../services/vehicle-service';
import { VehiclesModalComponent } from '../vehicles-modal-component/vehicles-modal-component';
import { VehiclesItemComponent } from '../vehicles-item-component/vehicles-item-component';

@Component({
  imports: [VehiclesItemComponent],
  selector: 'app-vehicles-list-page',
  styleUrl: './vehicles-list-page.css',
  templateUrl: './vehicles-list-page.html',
})
export class VehicleListPage implements OnInit {
  vehicleService = inject(VehicleService);
  private modalService = inject(NgbModal);

  vehicleList = signal<Result[]>([]);
  loading = signal(true);
  error = signal(false);

  ngOnInit(): void {
    this.vehicleService.getAll().subscribe({
      next: (resp) => {
        this.vehicleList.set(resp.results);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }

  openVehicleModal(id: string) {
    this.vehicleService.getOne(id).subscribe((resp) => {
      const modalRef = this.modalService.open(VehiclesModalComponent);
      modalRef.componentInstance.vehicleDetail = resp;
    });
  }


}
