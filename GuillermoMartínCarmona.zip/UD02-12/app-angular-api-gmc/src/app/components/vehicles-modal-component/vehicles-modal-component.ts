import { Component, inject, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { VehicleDetailResponse } from '../../interfaces/vehicle-detail-response';

@Component({
  imports: [],
  selector: 'app-vehicles-modal-component',
  styleUrl: './vehicles-modal-component.css',
  templateUrl: './vehicles-modal-component.html',
})
export class VehiclesModalComponent {
  activeModal = inject(NgbActiveModal);

  @Input() vehicleDetail: VehicleDetailResponse | undefined;


}
