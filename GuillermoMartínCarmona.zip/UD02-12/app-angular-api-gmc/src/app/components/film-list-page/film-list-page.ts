import { Component, inject, signal } from '@angular/core';
import { FilmItemComponent } from '../film-item-component/film-item-component';
import { FilmService } from '../../services/film-service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Result } from '../../interfaces/film-list-response';

@Component({
  imports: [],
  selector: 'app-film-list-paga',
  styleUrl: './film-list-page.css',
  templateUrl: './film-list-page.html',
})
export class FilmListPage {
  filmService = inject(FilmService);
  private modalService = inject(NgbModal);

  filmList = signal<Result[]>([]);
  loading = signal(true);
  error = signal(false);

  ngOnInit(): void {
    this.filmService.getAll().subscribe({
      next: (resp) => {
        this.filmList.set(resp.results);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }

  openFilmModal(id: string) {
    this.filmService.getOne(id).subscribe((resp) => {
      const modalRef = this.modalService.open(FilmItemComponent);
      modalRef.componentInstance.vehicleDetail = resp;
    });
  }



}
