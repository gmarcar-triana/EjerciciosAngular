import { Component, input, output } from '@angular/core';
import { Result } from '../../interfaces/vehicle-list-response';

@Component({
  imports: [],
  selector: 'app-vehicles-item-component',
  styleUrl: './vehicles-item-component.css',
  templateUrl: './vehicles-item-component.html',
})
export class VehiclesItemComponent {

  vehicle = input<Result>();
  vehicleClicked = output<string>();

  getVechicleId(): string {
    return this.vehicle()?.url.split("/")[5]!;
  }

  emitVehicleClicked() {
    this.vehicleClicked.emit(this.getVechicleId());
  }


}
