import { Component, input, output } from '@angular/core';
import { Result } from '../../interfaces/vehicle-list-response';

@Component({
  imports: [],
  selector: 'app-film-item-component',
  styleUrl: './film-item-component.css',
  templateUrl: './film-item-component.html',
})
export class FilmItemComponent {

  film = input<Result>();
  filmClicked = output<string>();

  getFilmId(): string {
    return this.film()?.url.split("/")[5]!;
  }

  emitFilmClicked() {
    this.filmClicked.emit(this.getFilmId());
  }

}
