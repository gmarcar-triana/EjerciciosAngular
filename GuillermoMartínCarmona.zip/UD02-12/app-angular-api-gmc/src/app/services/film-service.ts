import { inject, Service } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { FilmListResponse } from "../interfaces/film-list-response";
import { FilmDetailResponse } from "../interfaces/film-detail-response";

@Service()
export class FilmService {
    http = inject(HttpClient);

    getAll(): Observable<FilmListResponse> {
        return this.http.get<FilmListResponse>('https://swapi.dev/api/films/');
    }

    getOne(id: string): Observable<FilmDetailResponse> {
        return this.http.get<FilmDetailResponse>(`https://swapi.dev/api/films/${id}/`);
    }

}