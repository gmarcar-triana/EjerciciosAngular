import { Routes } from '@angular/router';
import { FilmListPage } from './components/film-list-page/film-list-page';
import { VehicleListPage } from './components/vehicles-list-page/vehicles-list-page';

export const routes: Routes = [
    {path: 'films', component: FilmListPage},
    {path: 'vehicles', component: VehicleListPage},
    {path: '', pathMatch: 'full', redirectTo: '/vehicles'}
];

