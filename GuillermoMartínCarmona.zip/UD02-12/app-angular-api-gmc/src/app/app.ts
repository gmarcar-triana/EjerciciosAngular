import { Component, signal } from '@angular/core';
import { VehicleListPage } from './components/vehicles-list-page/vehicles-list-page';

@Component({
  imports: [VehicleListPage],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  protected readonly title = signal('app-angular-api-gmc');
}
